package com.lti.java8lambda;

import java.util.ArrayList;
import java.util.List;

public class Lambda2 {
	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		list.add("aaa");
		list.add("mmm");
		list.add("aaa");
		list.add("jjj");
		
		list.forEach((n) -> System.out.println(n) );
	}
}
