package com.lti.java8lambda;

interface Addable {
	
	int add(int ...a);
}

public class Lambda1 {

	public static void main(String[] args) {
		
		//Addable a1 = (a, b) -> (a + b);
		//System.out.println(a1.add(1, 5));
		
		Addable a2 = (int ...a) -> { int s = 0; for(int x:a) s = s+x; return s;};
		System.out.println(a2.add(2, 8, 6, 5, 1));
	}
}
