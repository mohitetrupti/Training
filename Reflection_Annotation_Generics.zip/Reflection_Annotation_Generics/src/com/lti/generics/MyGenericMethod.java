package com.lti.generics;

public class MyGenericMethod {
	public <T> void show(T a[])
	{
		for (T t : a)
			System.out.print(t+" ");
	}
	public static void main(String[] args) {
		
		Integer x[]={12,33,45,76};
		new MyGenericMethod().show(x);
		String y[]={"INdia","BHutan"};
		new MyGenericMethod().show(y);
	}
}
