package com.lti.annotations;

public class Test2 {
	
	@Deprecated
	public void show1() {
		
		System.out.println("OLD");
	}
	
	public void show2() {
		
		System.out.println("NEW");
	}
	
	public static void main(String[] args) {
		
		new Test2().show1();
	}
}
