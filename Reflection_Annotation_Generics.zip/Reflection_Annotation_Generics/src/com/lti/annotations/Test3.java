package com.lti.annotations;

class A {
	
	public void show() {
		
		System.out.println("I am base");
	}
}

class B extends A {

	@Override
	public void show() {
		
		System.out.println("I am derived");
	}
	
	
}

public class Test3 {

	public static void main(String[] args) {
		
		B b = new B();
		b.show();
	}
}
