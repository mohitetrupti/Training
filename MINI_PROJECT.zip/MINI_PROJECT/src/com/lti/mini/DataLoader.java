package com.lti.mini;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import au.com.bytecode.opencsv.CSVReader;

public class DataLoader {
	
	public static void main(String[] args) throws SQLException  {
		
		PreparedStatement sql_statement = null;
		Connection conn = null;
		Statement st = null;
		
		try {
		Class.forName("oracle.jdbc.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		
		String insert_statement = "INSERT INTO US_COMPLAINTS" +"(cdate,Product,Sub_product,Issue,Sub_issue,Company,State,ZIP,Submitted_via,Date_sent_to_company,Company_response,Timely_response,Consumer_disputed,Complaint_ID) VALUES"+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		sql_statement = conn.prepareStatement(insert_statement);
		String csv_file = "D:\\complaints.csv";
		CSVReader reader = new CSVReader(new FileReader(csv_file));
		String [] nextLine;
		int total = 0;
		while ((nextLine = reader.readNext()) != null) {
			sql_statement.setString(1,nextLine[0]);
			sql_statement.setString(2,nextLine[1]);
			sql_statement.setString(3,nextLine[2]);
			sql_statement.setString(4,nextLine[3]);
			sql_statement.setString(5,nextLine[4]);
			sql_statement.setString(6,nextLine[5]);
			sql_statement.setString(7,nextLine[6]);
			sql_statement.setString(8,nextLine[7]);
			sql_statement.setString(9,nextLine[8]);
			sql_statement.setString(10,nextLine[9]);
			sql_statement.setString(11,nextLine[10]);
			sql_statement.setString(12,nextLine[11]);
			sql_statement.setString(13,nextLine[12]);
			sql_statement.setString(14,nextLine[13]);
			total = sql_statement.executeUpdate();
			
			
		}

			System.out.println("Total Records: " +total);
			st = conn.createStatement();
			st.executeUpdate("DELETE FROM US_COMPLAINTS WHERE Product='Product'");
		}
		catch(SQLException se) {
			
			System.out.println(se);
		}
		catch(ClassNotFoundException ce) {
			
			System.out.println(ce);
		}
		catch(FileNotFoundException fe) {
			
			System.out.println(fe);
		}
		catch(IOException ie) {
			
			System.out.println(ie);
		}
		finally {
			sql_statement.close();
			conn.commit();
			conn.close();
		}
	}
}
