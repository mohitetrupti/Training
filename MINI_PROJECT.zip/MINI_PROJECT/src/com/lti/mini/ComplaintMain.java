package com.lti.mini;

import java.util.Scanner;

public class ComplaintMain {

	public static void main(String[] args) throws Exception {
		
		int choice = 0;
		 Scanner sc= new Scanner(System.in);
		
		System.out.println("Choose the operation: ");
		System.out.println("1.Display complaints based on the year."
				+ "\n2.Display complaints based on the name of the bank provided by the user."+
				"\n3.Display complaints based on thye complaint ID provided by the user.\n");
		  
		choice = Integer.parseInt(sc.nextLine());
		switch(choice) {
		
		case 1:
			
			System.out.println("Enter the year :");
			String year = sc.nextLine();
			Complaint complaintYear = new Complaint();
			complaintYear.displayYearWiseComplaint(year);
			
		  
			break;
		case 2:
			System.out.println("Enter Name Of The Bank :");
			String bank_name = sc.nextLine();
			Complaint complaintBankName = new Complaint();
			complaintBankName.displayBankNameWiseComplaint(bank_name);
			break;
		case 3:
			System.out.println("Enter Complaint Id:");
			String c_id = sc.nextLine();
			Complaint complaintID = new Complaint();
			complaintID.displayIDWiseComplaint(c_id);
			break;
		case 4:
			System.out.println("Enter Complaint Id:");
			String c_id1 = sc.nextLine();
			Complaint complaintNoOfDays = new Complaint();
			complaintNoOfDays.displayDuration(c_id1);
			break;
		case 5:
			
			break;
		case 6:
			
			break;
		}
	}
}
