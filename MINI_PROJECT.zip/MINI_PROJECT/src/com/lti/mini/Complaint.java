package com.lti.mini;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Complaint {
	
	Connection conn = null;
	public void connect() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
	}

public void displayYearWiseComplaint(String year) throws Exception {
		connect();
		Statement st1 = conn.createStatement();
		ResultSet result_set = st1.executeQuery("SELECT cdate, product, sub_product, issue, sub_issue, company FROM US_COMPLAINTS where cdate LIKE '%"+year+"%'");
		
		//if(result_set.next()) {
			while(result_set.next()) {
				
				System.out.println(result_set.getString(1)+"\t"+result_set.getString(2)+"\t"+result_set.getString(3)+"\t"+result_set.getString(4)+"\t"+result_set.getString(5)+"\t"+result_set.getString(6));
			}
		conn.close();
		//}
	}


public void displayBankNameWiseComplaint(String bank_name) throws Exception {
	
	Statement st1 = conn.createStatement();
	ResultSet result_set = st1.executeQuery("SELECT cdate, product, sub_product, issue, sub_issue, company FROM US_COMPLAINTS where Company LIKE '%"+bank_name+"%'");
	while(result_set.next()) {
		
		System.out.println(result_set.getString(1)+"\t"+result_set.getString(2)+"\t"+result_set.getString(3)+"\t"+result_set.getString(4)+"\t"+result_set.getString(5)+"\t"+result_set.getString(6));
	}
}


public void displayIDWiseComplaint(String c_id) throws Exception {
	
	Statement st1 = conn.createStatement();
	ResultSet result_set = st1.executeQuery("SELECT cdate, product, sub_product, issue, sub_issue, company,Complaint_ID FROM US_COMPLAINTS where Complaint_ID LIKE '%"+c_id+"%'");
	while(result_set.next()) {
		
		System.out.println(result_set.getString(1)+"\t"+result_set.getString(2)+"\t"+result_set.getString(3)+"\t"+result_set.getString(4)+"\t"+result_set.getString(5)+"\t"+result_set.getString(6)+"\t"+result_set.getString(7));
	}
}


public void displayDuration(String complaintID) throws Exception {
	
	String date1 = null;
	String date2 = null;
	Class.forName("oracle.jdbc.OracleDriver");
	Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
	Statement st1 = conn.createStatement();
	ResultSet result_set = st1.executeQuery("SELECT cdate,Date_sent_to_company FROM US_COMPLAINTS where Complaint_ID='"+complaintID+"'");
	while(result_set.next()) {
		
		date1 = result_set.getString(1);
		date2 = result_set.getString(2);
		
		//System.out.println(result_set.getString(1)+"\t"+result_set.getString(2));
	}
	
	System.out.println(date1+" "+date2);
    Date c_date1=new SimpleDateFormat("dd/MM/yyyy").parse(date1);
    Date c_date2=new SimpleDateFormat("dd/MM/yyyy").parse(date2);
    
	long diff = c_date2.getTime() - c_date1.getTime();

	long diffDays = diff / (24 * 60 * 60 * 1000);

	System.out.print(diffDays + " days");
	
	

}		//method ends



}
