//Test class for ArrayList (Refer Book.java)

package com.lti.test;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListExample {

	public static void main(String[] args) {
		
		String choice=null;
		String data;
		Scanner sc = new Scanner(System.in);
		ArrayList<Book> bookList = new ArrayList<>();
		
		do {
		
			System.out.println("Enter the book details: ");
			data = sc.nextLine();
			String arr[] = data.split(",");
			Book book = new Book(arr[0], arr[1], Double.parseDouble(arr[2]));
			bookList.add(book);
			System.out.println("Do you want to continue? (YES/NO)");
			choice = sc.nextLine();
		} while (choice.equalsIgnoreCase("YES"));
		 for (Book book : bookList)
			 System.out.println(book.getBookName()+" "+book.getAuthorName()+" "+book.getPrice());
		 Book first = bookList.get(0);
		 Book last = bookList.get(bookList.size() - 1);
		 System.out.println("First: "+first.getBookName()+" "+first.getAuthorName()+" "+first.getPrice());
		 System.out.println("Last: "+last.getBookName()+" "+last.getAuthorName()+" "+last.getPrice());
		 sc.close();
	}
}
