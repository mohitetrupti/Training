//Test class for ArrayList (Refer Book.java)

package com.lti.testv2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ArrayListExample {

	public static void main(String[] args) {
		
		String choice=null;
		String data;
		Scanner sc = new Scanner(System.in);
		ArrayList<Book> bookList = new ArrayList<>();
		
		do {
		
			System.out.println("Enter the book details: ");
			data = sc.nextLine();
			String arr[] = data.split(",");
			Book book = new Book(arr[0], arr[1], Double.parseDouble(arr[2]));
			bookList.add(book);
			System.out.println("Do you want to continue? (YES/NO)");
			choice = sc.nextLine();
		} while (choice.equalsIgnoreCase("YES"));
		//Arraylist//Collections.sort(bookList);
		Collections.sort(bookList,new PriceComparator());
		 for (Book book : bookList)
			 System.out.println(book.getBookName()+" "+book.getAuthorName()+" "+book.getPrice());
		 sc.close();
	}
}
