package com.lti.testv2;

import java.util.HashMap;

public class HashMapSort2 {

	public static void main(String[] args) {
		
		System.out.println("hi");
		HashMap<Integer, String> hmap = new HashMap<>();
		hmap.put(189, "India");
		hmap.put(89, "Nepal");
		hmap.put(289, "Bhutan");
		System.out.println("hi");
		for(java.util.Map.Entry<Integer, String> entry: hmap.entrySet()) {
			
			Integer key = entry.getKey();
			String b = entry.getValue();
			System.out.println(key+" "+b);
		}
	}
}
