package com.jpaproj.app;

import com.jpaproj.model.Booking;
import com.jpaproj.model.Flight;
import com.jpaproj.model.Places;
import com.jpaproj.service.FlightDao;
import com.jpaproj.service.ServiceDao;

public class TestApplication {
public static void main(String[] args) {
	
	/*Places places = new Places();
	places.setLocation("Pune");
	places.setPlaceid(104);
	places.setPlacename("Hinjewadi");
	
	boolean flag = new ServiceDao().addPlaces(places);*/
	
	/*Places places = new Places();
	places.setPlaceid(103);
	Places p = new ServiceDao().getPlace(places);
	if(p == null)
		System.out.println("Place not found.");
	else
		System.out.println(p.getPlacename());
	
	System.exit(0);*/
	//System.out.println(flag);
	Flight flight = new Flight();
	flight.setFlightid("201");
	flight.setAirline("Indigo");
	flight.setSource("Pune");
	flight.setDestination("Mumbai");
	
	Booking booking1 = new Booking();
	//booking1.setBookingid(120);
	booking1.setPname("Trupti");
	booking1.setPage("21");

	Booking booking2 = new Booking();
	//booking2.setBookingid(121);
	booking2.setPname("Neha");
	booking2.setPage("22");

	
	 flight.getBookinglist().add(booking1);
	 flight.getBookinglist().add(booking2);
	 
	 boolean flag = new FlightDao().addFlight(flight);
	 
	 if(flag)
		 System.out.println("Done");
	 else
		 System.out.println("Fail");
	
}
}
