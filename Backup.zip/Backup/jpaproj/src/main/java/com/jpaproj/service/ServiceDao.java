package com.jpaproj.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.jpaproj.model.Places;

public class ServiceDao {

	public boolean addPlaces(Places places)
	{
		
		boolean result = false;
		
		try{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu12");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(places);
		em.getTransaction().commit();
		result = true;
		
		}
		catch (Exception e) {
		System.out.println("Error:"+e);
		}
		
		return result;
		
	}
	
	public Places getPlace(Places place) {
		
		Places p = null;
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu12");
			EntityManager em = emf.createEntityManager();
			p = em.find(Places.class, place.getPlaceid());
		}
		catch(Exception e) {
			
			System.out.println(e);
		}
		return p;
	}
	
}
