package model;

public class State {

	String state;
	String location;
	public State() {
		super();
	}
	public State(String state, String location) {
		super();
		this.state = state;
		this.location = location;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
}
