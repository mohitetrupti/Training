package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.State;

public class StateService {

public List<State> viewLocations(String sname) {
		
		List<State> tlist = new ArrayList<State>();
		
		State st = null;
		Connection connection = null;
		ResultSet rs = null;
		
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			Statement ps = connection.createStatement();
			rs = ps.executeQuery("SELECT * FROM States where sname=?");
			ps.setString(1, sname);
			rs = ps.executeQuery();

			if(rs.next()) {
				
				st = new State(rs.getString(1), rs.getString(2));
			}
			connection.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return st;
	}
}
