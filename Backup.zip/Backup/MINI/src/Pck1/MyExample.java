package Pck1;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Scanner;

import javax.print.attribute.standard.PrinterIsAcceptingJobs;

public class MyExample {
	public static void main(String[] args) {
		 Connection connection=null;
		 int bal=0;
		 Scanner sc=null;
		
		
		try {
			 sc =new Scanner(System.in);
			System.out.println("Enter  Account no:");
			int ac_send=Integer.parseInt(sc.nextLine());
			System.out.println("Enter  Reciever ACCOUNT no :");
			int acno_rec=Integer.parseInt(sc.nextLine());
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			Statement st= connection.createStatement();
			
		  ResultSet check =st.executeQuery("Select acno From accounts where acno="+ac_send);
		  if(check.next())	
		  {
			  ac_send=check.getInt(1);
			  System.out.println(ac_send);
		  }
			ResultSet check2=st.executeQuery("select acno from accounts where acno="+acno_rec);
			if(check2.next())
			{
				
				check2.getInt(1);
			}
			if(check.next() && check2.next())
			{
				
				System.out.println("Enter amount :");
				int amt=Integer.parseInt(sc.nextLine());
				
				
				ResultSet rs1=st.executeQuery("select amount from accounts where amount="+amt);
				if(rs1.next())
				{
					
					bal= rs1.getInt(amt);
					System.out.println("balance"+bal);
					
					bal-=amt;
					PreparedStatement pr=connection.prepareStatement("Update account set balance=?");
					pr.setInt(1,bal);
					pr.setInt(1,ac_send);
					int s=st.executeUpdate();
					int e=st.executeUpdate();
					if("")
					
					
 					}		
				
				
				
			}
			
			
			
						
			
		} catch (Exception e) {
			System.out.println(e.getMessage());

		
		
		}
		
	}


		
		
	

}
