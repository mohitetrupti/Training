package com.lti.testv2;

import java.util.HashMap;
import java.util.TreeMap;

public class HashMapSort {

	public static void main(String[] args) {
		
		HashMap<Integer, String> hmap = new HashMap<>();
		hmap.put(189, "India");
		hmap.put(89, "Nepal");
		hmap.put(289, "Bhutan");
		if (hmap.containsKey(89)) {
			String s=hmap.get(89);
			System.out.println(s);
			
		}
		
		TreeMap<Integer, String> tmap = new TreeMap<>(hmap);
		System.out.println(tmap);
		
		for(java.util.Map.Entry<Integer, String> entry: hmap.entrySet()) {
			
			Integer key = entry.getKey();
			String b = entry.getValue();
			System.out.println(key+" "+b);
		}
	}

}
