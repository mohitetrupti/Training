package com.lti.test;

import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class TreeMapExample {
	
	
	public static void main(String[] args) {

	
	String choice=null;
	String data;
	Scanner sc = new Scanner(System.in);
	//ArrayList<Book> bookList = new ArrayList<>();
	TreeMap<Integer, Book> bookList= new TreeMap<>();
	
	do {
	
		System.out.println("Enter the book details: [id,name,author,price]");
		data = sc.nextLine();
		String arr[] = data.split(",");
		Book book = new Book(arr[1], arr[2], Double.parseDouble(arr[3]));
		bookList.put(Integer.parseInt(arr[0]), book);
		//bookList.add(book);
		System.out.println("Do you want to continue? (YES/NO)");
		choice = sc.nextLine();
	} while (choice.equalsIgnoreCase("YES"));
	
	for(java.util.Map.Entry<Integer, Book> entry: bookList.entrySet()) {
		
		int key = entry.getKey();
		Book b = entry.getValue();
		System.out.println(key+" "+b.getBookName()+" "+b.getAuthorName()+" "+b.getPrice());
	}
	
	System.out.println("Search book id:");
	Integer id=Integer.parseInt(sc.nextLine());
	Book b= bookList.get(id);
	// for (Book book : bookList)
	if(b != null)
		 System.out.println(b.getBookName()+" "+b.getAuthorName()+" "+b.getPrice());
	else
		System.out.println("No data found.");
	 //Book first = bookList.get(id);
	 //Book last = bookList.get(bookList.size() - 1);
	 //System.out.println("First: "+first.getBookName()+" "+first.getAuthorName()+" "+first.getPrice());
	 //System.out.println("Last: "+last.getBookName()+" "+last.getAuthorName()+" "+last.getPrice());
	 sc.close();

}
}