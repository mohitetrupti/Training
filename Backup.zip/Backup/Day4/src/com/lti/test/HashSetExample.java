package com.lti.test;

import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;

public class HashSetExample {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int n = 0;
		int sum = 0;
		
		//TreeSet arranges the data in ascending order
		//TreeSet<Integer> numberList = new TreeSet<>();
		
		HashSet<Integer> numberList = new HashSet<>();
		
		while(true) {
			
			System.out.println("Enter a no: ");
			n = Integer.parseInt(sc.nextLine());
			if(n == 0)
				break;
			numberList.add(n);
		}
		
		System.out.println("The numbers are: ");
		for(Integer i: numberList) {
			System.out.println(i);
			sum = sum + i;
		}
		
		System.out.println("Sum: "+sum);
		System.out.printf("Average: %.2f", (double)sum/numberList.size());
		sc.close();
	}
}
