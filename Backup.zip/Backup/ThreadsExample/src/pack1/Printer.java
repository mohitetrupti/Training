package pack1;

class Printer1 {
    public void printer (String name) {
    	
    	System.out.println("["+name+" starts print");
    	try {
			
    		Thread.sleep(1000);
    		
		} catch (InterruptedException e) {
			 e.printStackTrace();
		}
    	System.out.println("]");
	

	}
}
class User extends Thread {
			
	
		String uname;
		Printer1 p;
		public User(String uname, Printer1 p)
		{
				super();
				
				this.uname=uname;
				this.p=p;
				}
		public void run()
		{
			synchronized (p) {
				p.printer(uname);
			}
		}
			
}


public class Printer {
	
	public static void main(String[] args) {
		Printer1 pr=new Printer1();
		User u1= new User("Jack",pr);
		User u2= new User("jill",pr);
		u1.start();
		u2.start();
	}
}