package com.lti.t1;

public class MyThread extends Thread{
	public MyThread(String a){
		super(a);
		
	}
		public void run()
		{
			for (int i = 1; i <= 10; i++) {
				
				System.out.println(i+""+getName());
				try{
					
					sleep(10);
				}
				catch (Exception e) {
				
				}
			}
		}
	
	
	
	public static void main(String[] args) {
		
		 MyThread T1= new MyThread("AAAAA");
				 T1.start();
		 MyThread T2= new MyThread("BBBB");
				 T2.start();
	}

}
