package com.lti.t1;

public class MyRunnableThread implements Runnable {
	
	Thread t;

	public MyRunnableThread(String a){

		t = new Thread(this, a);
		t.start();
	}
	
	public void run() {
		for (int i = 1; i <= 10; i++) {
				
			System.out.println(i+" "+t.getName());
			try{
					
				t.sleep(10);
			}
			catch (InterruptedException e) {
				System.out.println(e);
			}
		}
	}
	
	public static void main(String[] args) {
		
		 MyRunnableThread T1= new MyRunnableThread("AAAAA");
		 MyRunnableThread T2= new MyRunnableThread("BBBB");
	}
}
