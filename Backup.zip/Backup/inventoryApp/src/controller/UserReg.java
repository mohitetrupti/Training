package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Users;
import service.UsersDao;

/**
 * Servlet implementation class UserReg
 * Servlet class that gets the parameters from the HTML page
 */
@WebServlet("/UserReg")
public class UserReg extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public UserReg() {
    	super();
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userid = request.getParameter("eid");
		String name = request.getParameter("ename");
		String password = request.getParameter("pwd");
		String gender = request.getParameter("gender");
		String emailid = request.getParameter("email");
		String contactno = request.getParameter("contact");
		//PrintWriter pw = response.getWriter();
		//pw.print("uid:"+userid);
		Users users = new Users(userid,name,password,gender,emailid,contactno);

		try{
			boolean flag = new UsersDao().registerUser(users);
		
		if(flag){
			
			response.sendRedirect("Login.html");
		}
		else{
			response.sendRedirect("UserReg.html");
		}
			
		}		//try ends
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
