package Inherit1;

public class X {

	public void show() {
		
		System.out.println("I am X");
	}
}
