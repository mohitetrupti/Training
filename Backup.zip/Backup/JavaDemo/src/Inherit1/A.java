package Inherit1;

public class A {
	
	public A() {
		
		System.out.println("I am A");
	}
}
