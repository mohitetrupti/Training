package Inherit1;

public class Y extends X {
	
	public void show() {
		
		super.show();
		System.out.println("I am Y");
	}
}
