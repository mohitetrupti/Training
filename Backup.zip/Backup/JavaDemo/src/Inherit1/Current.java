package Inherit1;

public class Current extends Account {

	public Current() {
		super();
	}

	public Current(String acno, String name, int balance) {
		super(acno, name, balance);
	}

	@Override
	public void withdraw(int amount) {
		
		try {
			
			if((getBalance() - amount) < 5000)
				throw new Exception();
			else {

				setBalance(getBalance() - amount);
				System.out.println("The amount withdrawn is: "+amount);
				System.out.println("The current balance is: "+getBalance());
			}
			//super.withdraw(amount);
		}
		catch(Exception e) {
			
			System.out.println("Insufficient balance.");
		}
	}

}
