import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Account1 {
	String acno;
	String name;
	double balance;
	
	public Account1(String acno, String name, double balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}

	public String getAcno() {
		return acno;
	}

	public void setAcno(String acno) {
		this.acno = acno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
public static void main(String[] args) {
	
	
	InputStreamReader isr= new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(isr);
	
	
	 try{
		System.out.println("Enter the details: ");
		 String data = br.readLine();
		 String a[]=data.split(",",3);
		 Account1 account =new Account1(a[0],a[1],Double.parseDouble(a[2]));
		 System.out.printf("Name %s\n Acno %s \n balance :%.2f", account.getName().toUpperCase(), account.getAcno(), account.getBalance());
	 }
	 
	 catch(Exception e){
		 
		 e.printStackTrace();
	 }
}
}
