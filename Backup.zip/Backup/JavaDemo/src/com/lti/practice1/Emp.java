package com.lti.practice1;

public class Emp {
	
	private String name;
	private int age;
	
	public Emp() {
		this("Unknown", -1);
	}
	
	public Emp (String name, int age) {
		
		this.name = name;
		this.age = age;
	}
	
	public void show() {
		System.out.println("Emp [name=" + name + ", age=" + age + "]");
	}

	public static void main(String[] args) {
		
		Emp e1 = new Emp();
		e1.show();
		
		Emp e2 = new Emp("Msjkdfh", 27);
		e2.show();
	}
}
