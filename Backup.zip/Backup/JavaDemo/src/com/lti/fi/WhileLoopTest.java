package com.lti.fi;

public class WhileLoopTest {
	public static void main(String[] args) {
		
		int a = 18;
		int i = 0;
		
		/*while(i <= 10) {
			
			System.out.println(a*i);
			i++;
		
		}*/
		for( i=1;i<=10;i++)
		{
			System.out.println(a*i);
		}
		
	}
}
