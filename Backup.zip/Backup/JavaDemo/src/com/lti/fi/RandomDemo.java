package com.lti.fi;

import java.util.Random;
import java.util.Scanner;

public class RandomDemo {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a no.'s");
		int w = sc.nextInt();
		for (int i = 0; i <=10; i++) {
			System.out.println(w*i);
			
		}
		
		Random r1 = new Random();
		int x = r1.nextInt();
		if(x < 10)
			System.out.println("Blue");
		else
			System.out.println("Red");
	}
}
