package com.lti.fi;

public class Wrapper1 {
	
	/*public Integer some(Integer t) {
		
		System.out.println("t: "+t);
		return 20;
	}*/
	public static void main(String[] args) {
		
		/*Wrapper1 o = new Wrapper1();
		int a = 10;
		int b = o.some(a);
		System.out.println("b: "+b);*/
		 
		MyData d = new MyData();
		d.add();
	}
}
