package com.lti.fi;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo1 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int a = 10;
		int b;
		
		try{
		System.out.println("Enter a number: ");
		b = sc.nextInt();
		
		int c = a / b;
		System.out.println("c = "+c);
		}
		catch(InputMismatchException ie) {
			
			System.out.println("Character input not allowed.");
		}
		catch(ArithmeticException ae) {
			System.out.println(ae.getMessage());   
		}
		/*catch(Exception e) {
			System.out.println(e.getMessage());
		}*/
	}
}
