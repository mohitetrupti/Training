package com.lti.fi;

public class Demo2 {
	public void Oddeven(int a)
	{
		if(a%2==0)
		{
			
			System.out.println("No. is even");
		}
		else
		{
			
			System.out.println("No is odd");
		}
		
	}

}
