package com.lti.interface1;

public class InterfaceTest implements Interface1, Interface2 {

	@Override
	public void disp(int a) {
		System.out.println(a+data);
	}

	@Override
	public void show() {
		System.out.println("MY Output");
	}

	public static void main(String[] args) {
		InterfaceTest in = new InterfaceTest();
		in.disp(12);
		in.show();
	}
}
