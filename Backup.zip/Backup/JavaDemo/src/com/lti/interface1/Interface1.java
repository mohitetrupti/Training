package com.lti.interface1;

public interface Interface1 {
	int data = 20;
	public void show();          
}
