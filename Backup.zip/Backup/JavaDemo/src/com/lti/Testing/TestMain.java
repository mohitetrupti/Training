package com.lti.Testing;

import com.lti.practice1.Tour;

public class TestMain {
	public static void main(String[] args) {
		
		Tour t = new Tour(1, "Nashik", 23999, "02-10-2019");
		System.out.println(t);
		
		Tour t1 = new Tour();
		System.out.println(t1.getTour_id()+" "+t1.getPlace()+" "+t1.getCost()+" "+t1.getTour_date());
		t1.setTour_id(2);
		t1.setPlace("Pune");
		t1.setCost(24564);
		t1.setTour_date("02-08-2018");
		System.out.println(t1.getTour_id()+" "+t1.getPlace()+" "+t1.getCost()+" "+t1.getTour_date());
	}
}
