
public class Practice1 {

	public static void main(String[] args) {
		
		
	}
}
