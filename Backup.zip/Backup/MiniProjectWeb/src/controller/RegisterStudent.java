package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Student;
import service.StudentDao;

/**
 * Servlet implementation class RegisterStudent
 */
public class RegisterStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int rollno = Integer.parseInt(request.getParameter("rno"));
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String course = request.getParameter("course");
		String result = request.getParameter("res");
		
		PrintWriter out = response.getWriter();
		out.println("Name"+fname);
		
		Student student = new Student(rollno, fname, lname, course, result);
		
		try{
			boolean flag = new StudentDao().registerStudents(student);
		
		if(flag){
			
			RequestDispatcher rd = request.getRequestDispatcher("StudentHome.jsp");
			request.setAttribute("msg", "Student registered.");
			rd.forward(request, response);
		}
		else{
			
			RequestDispatcher rd = request.getRequestDispatcher("StudentHome.jsp");
			request.setAttribute("msg", "Oops! Registration Failed.");
			rd.forward(request, response);
		}
			
		}		//try ends
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
