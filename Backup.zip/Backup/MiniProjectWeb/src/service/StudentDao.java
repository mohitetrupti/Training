package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import model.Student;

public class StudentDao {

public boolean registerStudents(Student student){
		
		boolean result =false;
		
		Connection connection = null;
		//System.out.println(users.getContactno());
		
		try{
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			PreparedStatement ps= connection.prepareStatement("insert into studentinfo values(?,?,?,?,?)");
			ps.setInt(1, student.getRollno());
			ps.setString(2, student.getFname());
			ps.setString(3, student.getLname());
			ps.setString(4, student.getCourse());
			ps.setString(5, student.getResult());
		
			
			int rs= ps.executeUpdate();
			connection.close();
			if(rs > 0)					
				result=true;
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return result;
	}
}
