package aa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ComplaintYear {

	String year;

	public ComplaintYear(String year) {
		super();
		this.year = year;
	}

	/*public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}*/
	
	public void displayYearWiseComplaint() throws Exception {
		
		Class.forName("oracle.jdbc.OracleDriver");
		Connection conn = 		DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		Statement st1 = conn.createStatement();
		ResultSet result_set = st1.executeQuery("SELECT cdate, product, sub_product, issue, sub_issue, company FROM US_COMPLAINTS where cdate LIKE '%"+year+"%'");
		
		//if(result_set.next()) {
			while(result_set.next()) {
				
				System.out.println(result_set.getString(1)+"\t"+result_set.getString(2)+"\t"+result_set.getString(3)+"\t"+result_set.getString(4)+"\t"+result_set.getString(5)+"\t"+result_set.getString(6));
			}
		//}
	}
}
