package aa;

import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

public class ComplaintNoOfDays {

	String complaintID;

	public ComplaintNoOfDays(String complaintID) {
		super();
		this.complaintID = complaintID;
	}
	
	public void displayDuration() throws Exception {
		
		String date1 = null;
		String date2 = null;
		Class.forName("oracle.jdbc.OracleDriver");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		Statement st1 = conn.createStatement();
		ResultSet result_set = st1.executeQuery("SELECT cdate,Date_sent_to_company FROM US_COMPLAINTS where Complaint_ID='"+complaintID+"'");
		while(result_set.next()) {
			
			date1 = result_set.getString(1);
			date2 = result_set.getString(2);
			
			//System.out.println(result_set.getString(1)+"\t"+result_set.getString(2));
		}
		
		System.out.println(date1+" "+date2);
	    Date c_date1=new SimpleDateFormat("dd/MM/yyyy").parse(date1);
	    Date c_date2=new SimpleDateFormat("dd/MM/yyyy").parse(date2);
	    
		long diff = c_date2.getTime() - c_date1.getTime();

		long diffDays = diff / (24 * 60 * 60 * 1000);

		System.out.print(diffDays + " days");
		
		

	}		//method ends

}		//class ends

