package aa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ComplaintBankName {

	String bank_name;

	
	public ComplaintBankName(String bank_name) {
		super();
		this.bank_name = bank_name;
	}


	public void displayBankNameWiseComplaint() throws Exception {
		
		Class.forName("oracle.jdbc.OracleDriver");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		Statement st1 = conn.createStatement();
		ResultSet result_set = st1.executeQuery("SELECT cdate, product, sub_product, issue, sub_issue, company FROM US_COMPLAINTS where Company LIKE '%"+bank_name+"%'");
		while(result_set.next()) {
			
			System.out.println(result_set.getString(1)+"\t"+result_set.getString(2)+"\t"+result_set.getString(3)+"\t"+result_set.getString(4)+"\t"+result_set.getString(5)+"\t"+result_set.getString(6));
		}
	}
}
