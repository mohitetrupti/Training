package aa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ComplaintID {

	String c_id;

	public ComplaintID(String c_id) {
		super();
		this.c_id = c_id;
	}
	
	public void displayIDWiseComplaint() throws Exception {
		
		Class.forName("oracle.jdbc.OracleDriver");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		Statement st1 = conn.createStatement();
		ResultSet result_set = st1.executeQuery("SELECT cdate, product, sub_product, issue, sub_issue, company,Complaint_ID FROM US_COMPLAINTS where Complaint_ID LIKE '%"+c_id+"%'");
		while(result_set.next()) {
			
			System.out.println(result_set.getString(1)+"\t"+result_set.getString(2)+"\t"+result_set.getString(3)+"\t"+result_set.getString(4)+"\t"+result_set.getString(5)+"\t"+result_set.getString(6)+"\t"+result_set.getString(7));
		}
	}
}
