package com.lti.jdbcpractice1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class TestProcedure {
	
	public static void main(String[] args) {
	
	Connection connection = null;
	Scanner sc = null;
	
	sc = new Scanner(System.in);
	System.out.println("Enter id: ");
	int eid = Integer.parseInt(sc.nextLine());
	System.out.println("Enter name: ");
	String ename = sc.nextLine();
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		CallableStatement cs = connection.prepareCall("call proc1(?,?)");
		cs.setInt(1, eid);
		cs.setString(2, ename);
		cs.execute();
		
	}
	catch(ClassNotFoundException ce) {
		
		System.out.println(ce);
	}
	
	catch(SQLException se) {
		
		System.out.println(se);
	}
	
	finally {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		sc.close();
	}
	}

}
