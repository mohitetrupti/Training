package com.lti.jdbcpractice1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertTest2 {

	public static void main(String[] args) {
		
		Connection connection = null;
		Scanner sc = null;
		
		try {
			
			sc = new Scanner(System.in);
			System.out.println("Enter id: ");
			int id = Integer.parseInt(sc.nextLine());
			System.out.println("Enter name: ");
			String name = sc.nextLine();
			System.out.println("Enter marks: ");
			int marks = Integer.parseInt(sc.nextLine());
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			PreparedStatement ps = connection.prepareStatement("INSERT INTO student VALUES(?,?,?)"); 
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, marks);
			int r= ps.executeUpdate();
			System.out.println("Record is Updated"+r);
		}
		catch(ClassNotFoundException ce) {
			
			System.out.println(ce);
		}
		
		catch(SQLException se) {
			
			System.out.println(se);
		}
		finally {
			
			try {
				connection.close();
				sc.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
