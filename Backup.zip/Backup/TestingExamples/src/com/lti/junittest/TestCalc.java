package com.lti.junittest;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCalc {

	@Test
	public void test() {

		Calculator calculator = new Calculator();
		int res = calculator.sum(12, 23);
		assertEquals(35, res);
		
		boolean value = calculator.checkEven(56);
		//assertEquals(true, value);
		
		assertTrue(value);
	}

}
