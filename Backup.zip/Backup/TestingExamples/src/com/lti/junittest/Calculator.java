package com.lti.junittest;

public class Calculator {

	public int sum(int a, int b) {
		
		return (a+b);
	}
	
	public boolean checkEven(int number) {
		
		if(number % 2 == 0)
			return true;
		else
			return false;
	}
}
