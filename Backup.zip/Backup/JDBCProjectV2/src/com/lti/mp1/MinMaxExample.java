package com.lti.mp1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MinMaxExample {

	public static void main(String[] args) throws SQLException {
		
		Connection connection = null;
		Scanner sc= null;
		ResultSet rs = null;
		
		try{
			sc=new Scanner(System.in);
			System.out.println("Enter Min Salary: ");
			double min_sal=Double.parseDouble(sc.nextLine());
			System.out.println("Enter Max Salary");
			double max_sal=Double.parseDouble(sc.nextLine());
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			String sql = "Select employee_id, first_name,salary, department_id FROM employees WHERE salary BETWEEN "+min_sal+" and "+max_sal;
			
			Statement st = connection.createStatement();
			rs = st.executeQuery(sql);
			
			if(rs.next()) {
				do {
					
					System.out.println("Emp_id\tName\tSalary\tDept_id");
					System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getDouble(3)+"\t"+rs.getInt(4));
				}while(rs.next());
			}
			
			else {
				
				System.out.println("Sorry!!No records found.");
			}
		}
		catch(SQLException se) {
			
			System.out.println(se);
		}
		catch(ClassNotFoundException se) {
			
			System.out.println(se);
		}
		
		finally {
			sc.close();
			connection.close();
		}
	}
}
