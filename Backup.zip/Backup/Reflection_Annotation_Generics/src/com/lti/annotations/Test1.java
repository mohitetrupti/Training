package com.lti.annotations;

import java.util.ArrayList;

public class Test1 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		@SuppressWarnings("rawtypes")
		ArrayList alist = new ArrayList();
		alist.add(12);
		alist.add(78);
		System.out.println(alist);
	}
}
