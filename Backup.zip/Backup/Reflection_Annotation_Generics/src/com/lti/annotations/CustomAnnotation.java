package com.lti.annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface smartphone{
	
	String os();
	int version() default 1;
}
@smartphone(os="Android")
class Samsung{
	
		String model;

		public Samsung(String model) {
			super();
			this.model = model;
		} 
}
public class CustomAnnotation {
	
  public static void main(String[] args) {
	  
	  Samsung s= new Samsung("Galaxy");
	  System.out.println(s.model);
	  Class c =s.getClass();
	  Annotation ant =(smartphone)c.getAnnotation(smartphone.class);
	  smartphone sm= (smartphone) ant;
	  System.out.println(sm.os()+" "+sm.version());
	}
}
