package com.lti.java8lambda;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class Date_Time_API {

	
	
		public static void main(String[] args) throws DateTimeException {
			Calendar c= Calendar.getInstance();
			System.out.println(c);
			LocalDate dt= LocalDate.now();
			System.out.println("date is "+dt);
			
			
			LocalTime t= LocalTime.now();
			System.out.println("TIME is "+t);
			
			LocalDateTime ldt=LocalDateTime.now();
			System.out.println(" Date&TIME is "+ldt);
			
			Date md= new Date();
			System.out.println(md);
			
			
			//DateTimeFormatter dtf= DateTimeFormatter.ofPattern("YYYY-MM-DD HH:MM:SS");
			//String f= ldt.format(dtf);
			//System.out.println("In Formatted Manner"+f);
			
		}
		
}
