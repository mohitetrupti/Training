package com.lti.generics;

public class EnumExample {

	public enum Season { WINTER, SUMMER, SPRING, FALL}
	
	public static void main(String[] args) {
		
		for(Season s: Season.values())
			System.out.println(s);
		
		Season x = Season.FALL;
		System.out.println(x);
	}
}
