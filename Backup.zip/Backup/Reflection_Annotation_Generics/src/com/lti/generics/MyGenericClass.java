package com.lti.generics;

class MyClass<T> {
	
	private T data;

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
}

public class MyGenericClass {

	public static void main(String[] args) {
	
		MyClass<String> mc1 = new MyClass<String>();
		mc1.setData("LTI");
		System.out.println(mc1.getData());
		
		MyClass<Integer> mc2 = new MyClass<Integer>();
		mc2.setData(120);
		System.out.println(mc2.getData());
	}
}
