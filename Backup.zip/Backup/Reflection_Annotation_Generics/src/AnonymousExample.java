
interface A {
	
	public void show();
}


//Normal interface implementation
/*class B implements A {

	@Override
	public void show() {
		System.out.println("Majjjaaaaa");
	}
}*/

public class AnonymousExample {
	
	public static void main(String[] args) {
		
		//Anonymous class (ref)
		//Its interface's ref or obj
		A ref = new A() { 		
			@Override
			public void show() {
				
				System.out.println("Yahoooooooooooo!!!!");
			}
					
		};
	ref.show();
	
	
	//Normal object creation (ref2)
	/*A ref2 = new B();
	ref2.show();*/
	}
}
