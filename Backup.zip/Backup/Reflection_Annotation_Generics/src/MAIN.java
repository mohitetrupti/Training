import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
public class MAIN {
    public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Emp e = new Emp();
	Class c =e.getClass();
	System.out.println(c);
	Constructor cc[]=c.getConstructors();
	for (Constructor x:cc)
	{
		System.out.println(x);
	}
	
	Method method[]=c.getMethods();
	for (Method y :method) {
		System.out.println(y);
	}
		//e.setName("aaa");
		//e.getName("aavs");
		Method m1= c.getDeclaredMethod("setName", String.class);
		m1.invoke(e, "mar");
		System.out.println(e.getName());
	}
}
