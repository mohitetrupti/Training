package com.lti.f4;
import java.io.File;

public class FileProg {
	
	public static void main(String[] args) {
		
		String path = "D:\\eclipse-jee-neon-3-win32-x86_64\\eclipse";
		File file= new File(path);
		
		String arr[] = file.list();
		/*for(String a: arr) {
			System.out.println(a);
		}*/
		
		for(String a: arr) {
			
			file = new File(path + "\\" + a);
			if(file.isDirectory()) {
				
				System.out.println(a +" -(dir)");
			}
			else
				System.out.println(a +" -(file)");
		}
	}
}
