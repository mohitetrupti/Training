package com.lti.f4;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class IPTest {
	
	public static void main(String[] args) throws IOException {
		
		String path = "D:\\FileStuff";
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		fis = new FileInputStream(path+"\\Shinchan.png");
		fos = new FileOutputStream(path+"\\img.png");
			
		while(true) {
				
			int i = fis.read();
			if( i == -1 )
				break;
			fos.write(i);
		}
			
		fis.close();
		fos.close();
	}
}
