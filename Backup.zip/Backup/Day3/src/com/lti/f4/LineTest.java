package com.lti.f4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LineTest {
	
	public static void main(String[] args) throws IOException {
		
		FileReader fr = new FileReader("D:\\Lab-1.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String str;
		int cnt = 0;
		String word = "public";
		
		while((str = br.readLine()) != null) {
			cnt++;
			if(str.contains(word))
				System.out.println(cnt+": "+str);
		}
		
		fr.close();
	}
}
