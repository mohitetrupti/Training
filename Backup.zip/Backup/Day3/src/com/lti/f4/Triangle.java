package com.lti.f4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class SumException extends Exception {
	
	public SumException(String s) {
		System.out.println(s);
	}
}

public class Triangle {

	public static void main(String[] args) {
		
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			double a;
			double b;
			double c;
			double s;
			double area;
			
			System.out.println("Enter the sides: ");
			a = Double.parseDouble(br.readLine());
			b = Double.parseDouble(br.readLine());
			c = Double.parseDouble(br.readLine());
			
			if( (a + b) <= c || (b + c) <= a || (a + c) <= b) {
					throw new SumException("Sum of two sides should be greater than the third side.");
			}
			
			s = (a + b + c) / 2;
			
			area =  Math.sqrt(s * (s - a) * (s - b) * (s - c));
			
			System.out.println("The area of the triangle is: "+area);
			}
		
			catch(SumException se) {
				
				System.out.println("Caught!!!!");
			}
		
			catch(IOException ie) {
				
				//")System.out.println("Please provide input;
				System.out.println("erroe "+ie.getMessage());
			}
			catch(NumberFormatException nfe) {
				
				System.out.println("Please enter a number");
			}
	}
}
