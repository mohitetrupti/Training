package com.lti.f4;
import java.io.File;
public class TestFile {
	public static void main(String[] args) {
		File file= new File("d:\\Lab-1.txt");
		if(file.isFile()==true)
		{
			System.out.println("It is a file");
			System.out.println("FIle size is:"+ file.length());
		}
		else{
			System.out.println("Its a folder.");
			System.out.println("FIle size is:"+ file.length());
		}

		
	}

}
