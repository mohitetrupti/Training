package controller;


import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import model.RestResponse;
import model.Track;
import service.MyService;

@Path("/tracks")
public class MyController {
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	//Path with ID
	//@Path("/{songs}")
	
	public List<Track> viewTracks(){
		
		List<Track> tlist=new MyService().viewTracks();
		return tlist;
		
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{title}")
	public Track getTrackInfo(@PathParam("title") String title) {
		
		Track track = new MyService().getTrackInfo(title);
		return track;
	}
	@POST
	@Path("/post")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public RestResponse addTracks (Track track){
		
		boolean flag = new MyService().addTracks(track);
		RestResponse rs= new RestResponse();
		if(flag){
			rs.setCode(200);
			rs.setMessage("Successfully added");
			
		}else{
		rs.setCode(-1);
		rs.setMessage("NOT ADDED..");
		}
		return rs;
		
	}
	
	@POST
	@Path("/delete/{title}")
	@Produces(MediaType.APPLICATION_JSON)
	public RestResponse deleteTracks(@PathParam("title") String title){
		boolean flag= new MyService().deleteTracks(title);
		RestResponse rs=new RestResponse();
		if(flag){
			rs.setCode(200);
			rs.setMessage("Successfully Removed");
			
		}else{
		rs.setCode(-1);
		rs.setMessage("NOT Removed.");
		}
		return rs;
		
	
	}
	
	
	@PUT
	@Path("/update")
	@Produces(MediaType.APPLICATION_JSON)
	public RestResponse updateTracks(Track track){
		boolean flag= new MyService().updateTracks(track);
		RestResponse rs=new RestResponse();
		if(flag){
			rs.setCode(200);
			rs.setMessage("Successfully Updated");
			
		}else{
		rs.setCode(-1);
		rs.setMessage("NOT Updated");
		}
		return rs;
		
	
	}

}
