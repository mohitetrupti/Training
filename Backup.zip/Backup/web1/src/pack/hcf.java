package pack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class hcf
 */
public class hcf extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public hcf() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int num1 = Integer.parseInt(request.getParameter("num1"));
		int num2 = Integer.parseInt(request.getParameter("num2"));
		
		String selection = request.getParameter("choice");
		//String selection_lcm = request.getParameter("lcm");
		
		int a = num1;
        int b = num2;
		int t;
        
        while(b != 0)
        {
            t = b;
            b = a%b;
            a = t;
        }
		
        int hcf = a;
        int lcm = (num1*num2)/hcf;
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        if(selection.equals("hcf")) {
        	
        	out.println("<h3 style='color:red'>HCF: </h3>"+hcf);
        }
        else if(selection.equals("lcm")) {
        	
        	out.println("<h3 style='color:red'>LCM: </h3>"+lcm);
        }
        out.println("</body></html>");
        System.out.println("HCF: "+hcf);
        System.out.println("LCM: "+lcm);
	}

	
}
