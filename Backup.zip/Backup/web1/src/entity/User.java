package entity;

import java.io.Serializable;

public class User implements Serializable  {
		
		private String uid;
		private String pwd;
		private String uname;
		private int age;
		
		
		public User() {
			super();
		}
		
		public String getUid() {
			return uid;
		}
		
		public void setUid(String uid) {
			this.uid = uid;
		}
		
		public String getPwd() {
			return pwd;
		}
		
		public void setPwd(String pwd) {
			this.pwd = pwd;
		}
		
		public String getUname() {
			return uname;
		}
		
		public void setUname(String uname) {
			this.uname = uname;
		}
		
		public int getAge() {
			return age;
		}
		
		public void setAge(int age) {
			this.age = age;
		}
		
}
