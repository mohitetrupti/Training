package pack2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}*/

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = request.getParameter("uid");
		String pwd = request.getParameter("pwd");
		
		ServletConfig sc = getServletConfig();
		String a = sc.getInitParameter("uid");
		String b = sc.getInitParameter("pwd");
		
		if(user.equalsIgnoreCase(a) && pwd.equals(b)) 
		{
			//RequestDispatcher rd= request.getRequestDispatcher("welcome.html");
			//rd.forward(request, response);
			HttpSession session = request.getSession(true);		//retrieve session id
			session.setAttribute("uid", user);					//bind data to session
			response.sendRedirect("welcome.jsp");
			System.out.println("Login Successful.");
		}
		else {
			
			PrintWriter out = response.getWriter();
			out.println("<h3> Sorry Try again..</h3>");
		 //RequestDispatcher dr = request.getRequestDispatcher("login.html");
			//dr.include(request, response);
			response.sendRedirect("login.html");
			System.out.println("Fail");
		}
	}

}
