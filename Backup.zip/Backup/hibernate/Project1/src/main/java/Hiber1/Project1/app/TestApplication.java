package Hiber1.Project1.app;


import Hiber1.Project1.model.Employee;
import Hiber1.Project1.service.ServiceDao;

public class TestApplication {
	
	public static void main(String[] args) {
		
		//this employee object is transient
		Employee employee= new Employee();
		employee.setEno(100);
		employee.setEname("Alice");
		employee.setSalary(28000);
		
		//new ServiceDao();
		
		System.out.println(new ServiceDao().addEmployee(employee));
		
		//System.out.println(new ServiceDao().removeEmployee(employee));
		
		System.out.println(employee.getEname());
	}

}
