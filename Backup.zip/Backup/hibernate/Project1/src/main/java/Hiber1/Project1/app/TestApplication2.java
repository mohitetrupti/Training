package Hiber1.Project1.app;

import Hiber1.Project1.model.Employee;
import Hiber1.Project1.service.ServiceDao;

public class TestApplication2 {

public static void main(String[] args) {
		
		//this employee object is transient
		Employee employee= new Employee();
		employee.setEno(100);
		employee.setEname("Harry");
		employee.setSalary(19800);
		
		//new ServiceDao();
		
		System.out.println(new ServiceDao().updateEmployee(employee));
		
		System.out.println(employee.getEname());
	}
}
