package Hiber1.Project1.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Hiber1.Project1.model.Employee;
import Hiber1.Project1.model.SessionModel;
import Hiber1.Project1.model.Student;

public class ServiceDao {
	
	
	public boolean addEmployee(Employee e) {
		
		boolean result = false;
		
		try {
			
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.save(e);
			t.commit();
			session.close();
			result = true;
		}
		
		catch(Exception ex) {
			
			System.out.println(ex);
		}
		
		return result;
	}
	
	public boolean removeEmployee(Employee e) {
		
		boolean result = false;
		
		try {
			
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.delete(e);
			t.commit();
			session.close();
			result = true;
		}
		catch(Exception ex) {
			
			System.out.println(ex);
		}
		
		return result;
	}
	
	public boolean updateEmployee(Employee e) {
		
		boolean result = false;
		
		try {
			
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.update(e);
			t.commit();
			session.close();
			result = true;
		}
		
		catch(Exception ex) {
			
			System.out.println(ex);
		}
		
		return result;
	}
	
	public Employee getEmployee(Employee e){
		
		Employee e1=null;
		try {
			
			Session session = new SessionModel().getSession();
			e1 = (Employee)session.get(Employee.class, e.getEno());
		}
		catch (Exception ex) {
		 System.out.println(ex);
		}
		return e1;
		
	}

public boolean addStudent(Student s) {
		
		boolean result = false;
		
		try {
			
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.save(s);
			t.commit();
			session.close();
			result = true;
		}
		
		catch(Exception ex) {
			
			System.out.println(ex);
		}
		
		return result;
	}
}
