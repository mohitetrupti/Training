package Hiber1.Project1.model;

import java.util.Calendar;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class Student {

	
	@Id
	private int id;
	private String name;
	@Temporal(TemporalType.DATE)
	private Calendar dob;
	
	public Student() {
		super();
	}
	public Student(int id, String name, Calendar dob) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Calendar getDob() {
		return dob;
	}
	public void setDob(Calendar dob) {
		this.dob = dob;
	}

}
