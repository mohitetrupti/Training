package Hiber1.Project1.app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import Hiber1.Project1.model.Student;
import Hiber1.Project1.service.ServiceDao;

public class TestappDate {

	public static void main(String[] args) throws ParseException {
		Student student= new Student();
		student.setId(101);
		student.setName("Harry");
		//student.setDob(12-11-1);
		
		//new ServiceDao();
		
		Calendar cal = Calendar.getInstance();
		cal.set(1997, 11, 12);
		
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal.getTime());
		// Output "Wed Sep 26 14:23:28 EST 2012"

		String formatted = format1.format(cal.getTime());
		System.out.println(formatted);
																																																																																																																																																																																					
		cal.setTime(format1.parse(formatted));
		
		student.setDob(cal);
		System.out.println(new ServiceDao().addStudent(student));
		
		
	}
	
	
}
