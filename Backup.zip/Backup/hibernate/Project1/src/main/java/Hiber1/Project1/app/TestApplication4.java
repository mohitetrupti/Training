package Hiber1.Project1.app;

import Hiber1.Project1.model.Employee;
import Hiber1.Project1.service.ServiceDao;

public class TestApplication4 {

	
public static void main(String[] args) {
		
		//this employee object is transient
		Employee employee= new Employee();
		employee.setEno(102);
		
		//new ServiceDao();
		
		Employee e = new ServiceDao().getEmployee(employee);
		if(e!=null){
			
			
			System.out.println(e.getEname());
		}
		else{
			
			System.out.println("Not found");
		}
		//System.out.println(employee.getEname());
	}
}
