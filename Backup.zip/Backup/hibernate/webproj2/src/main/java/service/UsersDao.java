

package service;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Users;

public class UsersDao {
	public Users getUserInfo(String uid){
		
		Users users=null;
		
		Connection connection = null;
		//System.out.println(users.getContactno());
		
		try{
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
		PreparedStatement ps= connection.prepareStatement("Select * from empusers ");
		ps.setString(1,uid);
		ResultSet rs= ps.executeQuery();
		if(rs.next()){
			users = new Users (rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
			
		}
		connection.close();	
		}
		catch(Exception e) {
			
			System.out.println(e);
		}
		return users;
	}
	
	//Add users in the database
	//Returns true if data is inserted successfully, else returns false
	public boolean registerUser(Users users){
		boolean result=false;
		
		//the code goes here
		
		Connection connection = null;
		//System.out.println(users.getContactno());
		
		try{
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			PreparedStatement ps= connection.prepareStatement("insert into empusers values(?,?,?,?,?,?)");
			ps.setString(1, users.getUserid());
			ps.setString(2, users.getName());
			ps.setString(3, users.getPassword());
			ps.setString(4, users.getContactno());
			ps.setString(5, users.getEmailid());
			ps.setString(6, users.getGender());
			
			int rs= ps.executeUpdate();
			connection.close();
			if(rs > 0)					
				result=true;
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
				return result;
		
	}
	
	
	public boolean checkLogin(Users users){
		
		boolean result = false;
		
		//the code goes here
		
				Connection connection = null;
				ResultSet rs = null;
				//System.out.println(users.getContactno());
				
				try{
					
				
					Class.forName("oracle.jdbc.driver.OracleDriver");
				connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
				
					PreparedStatement ps = connection.prepareStatement("SELECT * FROM empusers WHERE empid=? AND password=?");
					
					ps.setString(1, users.getUserid());
					ps.setString(2, users.getPassword());
					
					rs = ps.executeQuery();
					if( rs.next() ) {
						
						result = true;
						connection.close();
					}
				}
				catch(Exception e) {
					System.out.println(e);
				}
				
				
		return result;
	}

}
