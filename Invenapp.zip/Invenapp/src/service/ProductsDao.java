package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Product;

public class ProductsDao {
	
	public boolean addProducts(Product product){
		
		boolean result =false;
		
		Connection connection = null;
		//System.out.println(users.getContactno());
		
		try{
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			PreparedStatement ps= connection.prepareStatement("insert into product values(?,?,?,?,?)");
			ps.setString(1, product.getPid());
			ps.setString(2, product.getPname());
			ps.setInt(3, product.getPrice());
			ps.setInt(4, product.getStock());
			ps.setString(5, product.getCategory());
		
			
			int rs= ps.executeUpdate();
			connection.close();
			if(rs > 0)					
				result=true;
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
		
		
		return result;
	}
	
	public List<Product> viewProducts() {
		
		List<Product> plist = new ArrayList<Product>();
		
		Connection connection = null;
		ResultSet rs = null;
		//System.out.println(users.getContactno());
		
		try{
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			Statement ps = connection.createStatement();
			rs = ps.executeQuery("SELECT * FROM product");


			while(rs.next()) {
				
				Product prod = new Product(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5));
				plist.add(prod);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		

		
		return plist;
	}

}
