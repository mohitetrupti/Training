package com.lti.f4;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class Emp implements Serializable {

	private String name;
	//private int age;				//This will persist
	private transient int age;		//transient cannot be persistent
	
	
	public Emp(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}


	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
	 	
		Emp e = new Emp("Trupti",21);
		
		//Writing objects into file to achieve persistence(object to byte)
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("D:\\obj.bin"));
		oos.writeObject(e);
		oos.close();
		
		
		//Reading the objects stored in the file(byte to object)
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\obj.bin"));
		Emp e1= (Emp)ois.readObject();		//Downcasting
		ois.close();
		System.out.println(e1.name+ " "+e1.age);
	}
}
