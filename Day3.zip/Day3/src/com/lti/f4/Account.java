package com.lti.f4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Account {
 
	private String acno;
	private String name;
	private String input;
	private double balance;
	
	public void inout() {
		
		try {
			
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("Enter the details: ");
			input = br.readLine();
			
			String arr[] = input.split(",");
			
			acno = arr[0];
			name = arr[1];
			balance = Double.parseDouble(arr[2]);
			
			System.out.println("Name: "+name.toUpperCase()+"\nAccountNo.: "+acno+"\nBalance: "+balance);
		}
		catch(IOException ie) {
			
			System.out.println("Caught");
		}
	}
	
	public static void main(String[] args) {
		
		Account ac = new Account();
		ac.inout();
		
	}
}
