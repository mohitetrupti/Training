package com.lti.f4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Circle {

	public static void main(String[] args) {
		
		try {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		double radius;
		
		System.out.println("Enter radius: ");
		radius = Double.parseDouble(br.readLine());
		
		double area =  Math.PI * radius * radius;
		
		System.out.println("The area of the circle is: "+area);
		}
		catch(IOException ie) {
			
			//")System.out.println("Please provide input;
			System.out.println("erroe "+ie.getMessage());
		}
		catch(NumberFormatException nfe) {
			
			System.out.println("Please enter a number");
		}
	}
}
