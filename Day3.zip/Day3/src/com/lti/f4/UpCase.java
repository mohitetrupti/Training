package com.lti.f4;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class UpCase {
	public static void main(String[] args) throws IOException {
		
		String path = "D:\\";
		FileReader fr = null;
		FileWriter fw = null;
		
		fr = new FileReader(path+"Lab-1.txt");
		fw = new FileWriter(path+"Lab-2.txt");
			
		while(true) {
				
			int i = fr.read();
			//System.out.print(Character.toString((char)i).toUpperCase());
			if( i == -1 )
				break;
			//String s = Character.toString((char)i).toUpperCase(); 
			i=Character.toUpperCase(i); 

			fw.write(i);
		}
			
		fr.close();
		fw.close();
	}

}
