package com.lti.jdbcpractice1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SelectTest {
	
	public static void main(String[] args) {
	
		Connection connection = null;
		ResultSet rs = null;
		Scanner sc = null;
		try {
			
			sc = new Scanner(System.in);
			System.out.println("Enter id: ");
			int id = Integer.parseInt(sc.nextLine());
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			PreparedStatement statement = connection.prepareStatement("SELECT sname,stotal FROM student WHERE student_id=?");
			statement.setInt(1, id);
			rs =  statement.executeQuery();
			if(rs.next()) {
				 int total= rs.getInt("stotal");
				 System.out.println("Name: "+rs.getString("sname"));
				 System.out.println("Marks: "+total);
				 if(total<500){
					 System.out.println("Remark: Fail");
				 }
				 else
					 System.out.println("Remark: Pass");
			}
			else
				System.out.println("Record not found.");
		}
		catch(ClassNotFoundException ce) {
			
			System.out.println(ce);
		}
		
		catch(SQLException se) {
			
			System.out.println(se);
		}
		finally {
			
			try {
				connection.close();
				sc.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	
		
}


