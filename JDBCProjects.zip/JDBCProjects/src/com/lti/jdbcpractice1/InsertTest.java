package com.lti.jdbcpractice1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertTest {

	public static void main(String[] args) {
		
		Connection connection = null;
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			Statement statement = connection.createStatement();
			statement.executeUpdate("INSERT INTO student VALUES(101,'Neha',234)");
			
		}
		catch(ClassNotFoundException ce) {
			
			System.out.println(ce);
		}
		
		catch(SQLException se) {
			
			System.out.println(se);
		}
		finally {
			
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
