package com.lti.jdbcpractice1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class AccountTest {
public static void main(String[] args) {
	int bal = 0;
	Connection connection = null;
	Scanner sc= null;
	try {
		
		sc=new Scanner(System.in);
		System.out.println("Enter Your Account no: ");
		int acno_send=Integer.parseInt(sc.nextLine());
		System.out.println("Enter Recipent's acno");
		int acno_rec=Integer.parseInt(sc.nextLine());
		
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		Statement st = connection.createStatement();
		
		ResultSet check = st.executeQuery("select acno from accounts where acno="+acno_send);
		if(check.next())
			acno_send = check.getInt(1);
		ResultSet check2 = st.executeQuery("select acno from accounts where acno="+acno_rec);
		if(check2.next())
			acno_rec = check2.getInt(1);
		if(check.next() && check2.next()) {	
			
			System.out.println("Enter amount :");
			int amt=Integer.parseInt(sc.nextLine());
		
			ResultSet rs = st.executeQuery("Select balance from accounts where acno="+acno_send);
			if(rs.next())
				bal = rs.getInt("balance");
			System.out.println("Balance = "+bal);
			bal -= amt;
			PreparedStatement statement = connection.prepareStatement("Update Accounts set balance=? where acno=?");
			statement.setInt(1, bal);
			statement.setInt(2, acno_send);
			rs = st.executeQuery("Select balance from accounts where acno="+acno_rec);
			if(rs.next())
				bal = rs.getInt("balance");
			bal += amt;
			PreparedStatement statement2 = connection.prepareStatement("Update Accounts set balance=? where acno=?");
			statement2.setInt(1, bal);
			statement2.setInt(2, acno_rec);
			 int s=statement.executeUpdate();
			int r= statement2.executeUpdate();
			System.out.println("r="+r+"\ns="+s);
		}
		else {
			System.out.println("One of the accounts do not exist. Transaction failed.");
		}
	}
	catch(ClassNotFoundException ce) {
		
		System.out.println(ce);
	}
	
	catch(SQLException se) {
		
		System.out.println(se);
	}
	finally {
		
		try {
			connection.close();
			sc.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
}
}
