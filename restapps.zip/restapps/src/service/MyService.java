package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import model.Track;


public class MyService {

	
public List<Track> viewTracks() {
		
		List<Track> tlist = new ArrayList<Track>();
		
		Connection connection = null;
		ResultSet rs = null;
		
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			Statement ps = connection.createStatement();
			rs = ps.executeQuery("SELECT * FROM Track");

			while(rs.next()) {
				
				Track track = new Track(rs.getString(1), rs.getString(2));
				tlist.add(track);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return tlist;
	}

	public Track getTrackInfo(String title) {
		
		Track track = null;
		
		Connection connection = null;
		ResultSet rs = null;
		
		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM Track where title=?");
			ps.setString(1, title);
			rs = ps.executeQuery();

			if(rs.next()) {
				
				track = new Track(rs.getString(1), rs.getString(2));
			}
			connection.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return track;
	}
	
public boolean addTracks(Track track){
		
		boolean result =false;
		
		Connection connection = null;
		//System.out.println(users.getContactno());
		
		try{
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
		
			PreparedStatement ps= connection.prepareStatement("insert into Track values(?,?)");
			ps.setString(1, track.getTitle());
			ps.setString(2, track.getSinger());
		
		
			
			int rs= ps.executeUpdate();
			connection.close();
			if(rs > 0)					
				result=true;
			
		}
		catch(Exception ex) {
			System.out.println(ex);
		}return result;
}
		
		public boolean deleteTracks(String title){
			
			boolean result =false;
			
			Connection connection = null;
			//System.out.println(users.getContactno());
			
			try{
				
			
				Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			
				PreparedStatement ps= connection.prepareStatement("DELETE from Track where title=? ");
				ps.setString(1, title);
				int rs= ps.executeUpdate();
				connection.close();
				if(rs > 0)					
					result=true;
				
			}
			catch(Exception e) {
				System.out.println(e);
			}
			
     return result;
		
		
	}
		
		public boolean updateTracks(Track track){
			
			boolean result =false;
			
			Connection connection = null;
			//System.out.println(users.getContactno());
			
			try{
				
			
				Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = 			DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			
				PreparedStatement ps= connection.prepareStatement("update Track set singer=? where title=?");
				ps.setString(2, track.getTitle());
				ps.setString(1, track.getSinger());
			
			
				
				int rs= ps.executeUpdate();
				connection.close();
				if(rs > 0)					
					result=true;
				
			}
			catch(Exception ex) {
				System.out.println(ex);
			}return result;
	}

}
