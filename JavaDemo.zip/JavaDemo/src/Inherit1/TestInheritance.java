package Inherit1;

//import com.lti.practice1.A;
//import com.lti.practice1.B;

public class TestInheritance {
	public static void main(String[] args) {
		
		/*X objX = new X();
		objX.show();
		
		System.out.println("------------");
		
		Y objY = new Y();
		objY.show();*/
		
		
		//Run-time polymorphism (Overriding)
		/*X obj;
		obj = new Y();
		obj.show();
		
		System.out.println("------------");
		
		obj = new X();
		obj.show();*/
		
		/*X objX = new X();
		Y objY = new Y();
		
		X obj1 = objY;
		
		try {
		Y obj2 = (Y)objX;
		obj2.show();
		}
		catch(ClassCastException ce) {
			
			System.out.println(ce.getMessage());
		}*/
		
		
		Savings sav = new Savings("1235464778","Neha",6000);
		System.out.println(sav);
		sav.deposit(2000);
		sav.withdraw(7500);
		sav.withdraw(700);
		
		
		
		Current cur = new Current("1235334343","Trupti",2000);
		System.out.println(cur);
		cur.deposit(1000);
		cur.withdraw(3000);
		
	}
}
