package com.lti.fi;
import java.util.Arrays;

public class Demo1 {
	
	private void factorial(int n) {
	
		int fact=1;
		int i = 1;
		while(i <= n) {
			
			fact = fact * i;
			i++;
		}
		System.out.println(fact);
	}
	
	public void arrayDemo() {
		
		int sum = 0;
		int prod = 1;
		int arr[] = {10, 53, 30, 40, 50};
		
		for(int i = 0; i < arr.length; i++) {
			
			sum += arr[i];
			prod *= arr[i];
			System.out.println(arr[i]);
			System.out.println("Sum: "+sum);
			System.out.println("Product: "+prod);
		}
		
		System.out.println("Ascending: ");
		Arrays.sort(arr);
		
		System.out.println("Descending: ");
		
		for(int i = arr.length-1; i >= 0; i--) {
			System.out.println(arr[i]);
		}	
		
		//System.out.println("Using for-each");
		
		/*for(int x: arr)
			System.out.println(x);*/
	}

	public void callingMethod() {
		
		factorial(5);
	}
}
