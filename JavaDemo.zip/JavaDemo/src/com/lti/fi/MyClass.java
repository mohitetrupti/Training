package com.lti.fi;

public class MyClass {
	public static void main(String ar[]) {
			
			/*int a = 10;
			int b = 20;
			
			float x = 10.4f;
			float y = 20.4f;
	
			double e = 10.3;
			double f = 20.5;
			
			char c = 'S';
			String str = "NehaTrupti";
	
			System.out.println("The addition is: "+(a+b));
			System.out.println("The addition is: "+(x+y));
			System.out.println("The addition is: "+(e+f));
			System.out.println("Character: "+c);
			System.out.println("String: "+str);*/
		
		
			Demo2 d = new Demo2();
			//d.Oddeven(9);
			
			Demo1 d1 = new Demo1();
			d1.arrayDemo();
	}
}
