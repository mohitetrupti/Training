package com.lti.fi;

public class MyData {
	int a;
	int b;
	public MyData()
	{
		a=10;
		b=20;
	}
	public MyData(int x,int y)
	{
		a=x;
		b=y;
		
	}
public void add() {
	System.out.println(a+b);
}

}
