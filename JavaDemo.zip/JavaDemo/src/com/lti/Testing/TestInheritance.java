package com.lti.Testing;

import com.lti.practice1.A;
import com.lti.practice1.B;

public class TestInheritance {
	public static void main(String[] args) {
		
		A objA = new A();
		objA.show();
		
		B objB = new B();
		objB.display();
		objB.show();
	}
}
