package com.lti.inherit2;

abstract public class Account {
	private String acno;
	private String name;
	private int balance;
	
	public Account() {
		super();
	}
	
	public Account(String acno, String name, int balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}
	public String getAcno() {
		return acno;
	}
	public void setAcno(String acno) {
		this.acno = acno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	
	@Override
	public String toString() {
		return "Account [acno=" + acno + ", name=" + name + ", balance=" + balance + "]";
	}

	public void deposit(int amount){
		
		balance += amount;
		System.out.println("The amount deposited is: "+amount);
		System.out.println("The current balance is: "+balance);
	}
	
	abstract public void withdraw(int amount);
	
}