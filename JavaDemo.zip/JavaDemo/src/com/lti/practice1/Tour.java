package com.lti.practice1;

//import java.util.Date;

public class Tour {
	private int tour_id;
	private String place;
	private double cost;
	//private java.util.Date tour_date;
	private String tour_date;
	
	
	//Parameterized constructor
	public Tour(int tour_id, String place, double cost, String tour_date) {
		
		super();
		this.tour_id = tour_id;
		this.place = place;
		this.cost = cost;
		this.tour_date = tour_date;
	}
	
	//Default constructor
	public Tour() {
		super();
	}

	
	//Getters and Setters
	public int getTour_id() {
		return tour_id;
	}
	public void setTour_id(int tour_id) {
		this.tour_id = tour_id;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public String getTour_date() {
		return tour_date;
	}
	public void setTour_date(String tour_date) {
		this.tour_date = tour_date;
	}


	//toString (to print)
	@Override  
	public String toString () {
		return "Tour [tour_id=" + tour_id + ", place=" + place + ", cost=" + cost + ", tour_date=" + tour_date + "]";
	}
	
}
