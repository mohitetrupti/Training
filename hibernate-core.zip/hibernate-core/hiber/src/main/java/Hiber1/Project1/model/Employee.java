package Hiber1.Project1.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee123")
public class Employee {

	@Id
	private int eno;
	private String ename;
	@Column(name="esal")		//this is the column name in the table
	private int salay;
	public Employee() {
		super();
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSalay() {
		return salay;
	}
	public void setSalay(int salay) {
		this.salay = salay;
	}
	public Employee(int eno, String ename, int salay) {
		super();
		this.eno = eno;
		this.ename = ename;
		this.salay = salay;
	}
	
	
	
	
	
}
